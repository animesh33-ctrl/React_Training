import FilterPanel from "./components/FilterPanel";
import SummaryHeader from "./components/SummaryHeader";
import TicketDetails from "./components/TicketDetails";
import TicketList from "./components/TicketList";

const App = () => {
  return (
    <div>
      <header>
        <h1>Customer Support Ticket Workspace</h1>
        <SummaryHeader />
      </header>
      <FilterPanel />
      <main>
        <section>
          <TicketList />
        </section>
        <section>
          <TicketDetails />
        </section>
      </main>
    </div>
  );
};

export default App;
