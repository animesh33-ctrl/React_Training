import { IoIosStar, IoIosStarOutline } from "react-icons/io";
import { selectTicket, toggleStar } from "../store/ticketSlice";
import { useDispatch } from "react-redux";

const TicketItem = ({ ticket }) => {
  const dispatch = useDispatch();
  return (
    <div
      onClick={() => dispatch(selectTicket(ticket.id))}
      className="bg-white border border-gray-200 rounded-xl p-4 flex justify-between items-center shadow-sm hover:shadow-md transition duration-300"
    >
      <div className="border-l-4 border-orange-400 pl-4 flex-1">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-gray-400 font-medium">{ticket.id}</span>

          <span
            className={`px-2 py-0.5 text-xs font-semibold rounded-md
              ${
                ticket.priority === "High"
                  ? "bg-red-100 text-red-600"
                  : ticket.priority === "Medium"
                    ? "bg-orange-100 text-orange-600"
                    : "bg-green-100 text-green-600"
              }`}
          >
            {ticket.priority.toUpperCase()}
          </span>
        </div>

        <h3 className="text-xl font-semibold text-gray-800">
          {ticket.issueTitle}
        </h3>

        <p className="text-gray-500 mt-1">{ticket.customerName}</p>
      </div>

      <div className="flex flex-col items-end gap-4">
        <button
          onClick={() => dispatch(toggleStar(ticket.id))}
          className="text-blue-600  text-xl transition hover:scale-[1.1]"
        >
          {ticket.starred ? <IoIosStar /> : <IoIosStarOutline />}
        </button>

        <span
          className={`px-4 py-1 text-sm rounded-full font-medium
            ${
              ticket.status === "Open"
                ? "bg-orange-100 text-orange-600"
                : ticket.status === "In Progress"
                  ? "bg-yellow-100 text-yellow-700"
                  : "bg-green-100 text-green-600"
            }`}
        >
          {ticket.status}
        </span>
      </div>
    </div>
  );
};

export default TicketItem;
