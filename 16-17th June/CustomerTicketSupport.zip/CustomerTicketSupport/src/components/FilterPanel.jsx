import { FILTERS } from "../data/ticketMeta";
import { useDispatch } from "react-redux";
import { filterTicket } from "../store/ticketSlice";

const FilterPanel = () => {
  const dispatch = useDispatch();

  const handleClick = (filterValue) => {
    dispatch(filterTicket(filterValue));
  };
  return (
    <div>
      <h5>FilterPanel</h5>
      <div>
        {FILTERS.map((filter) => {
          return (
            <button key={filter} onClick={() => handleClick(filter)}>
              {filter}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default FilterPanel;
