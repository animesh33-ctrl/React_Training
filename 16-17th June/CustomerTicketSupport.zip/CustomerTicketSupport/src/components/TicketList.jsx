import { useSelector } from "react-redux";
import { showTicketList } from "../store/ticketSlice";
import TicketItem from "./TicketItem";

const TicketList = () => {
  const tickets = useSelector((state) => showTicketList(state.ticket));

  return (
    <div>
      <h3>TicketList</h3>
      <div>
        {tickets.map((ticket) => (
          <TicketItem key={ticket.id} ticket={ticket} />
        ))}
      </div>
    </div>
  );
};

export default TicketList;