import { useSelector } from "react-redux";
import {
  inProgress,
  open,
  resolved,
  starred,
  totalTickets,
} from "../store/ticketSlice";

const SummaryHeader = () => {
  const total = useSelector((state) => totalTickets(state.ticket));
  const openCount = useSelector((state) => open(state.ticket));
  const inProgressCount = useSelector((state) => inProgress(state.ticket));
  const resolvedCount = useSelector((state) => resolved(state.ticket));
  const starredCount = useSelector((state) => starred(state.ticket));

  return (
    <div>
      <div>
        <h4>Total Tickets</h4>
        <p>{total}</p>
      </div>
      <div>
        <h4>Open</h4>
        <p>{openCount}</p>
      </div>
      <div>
        <h4>In Progress</h4>
        <p>{inProgressCount}</p>
      </div>
      <div>
        <h4>Resolved</h4>
        <p>{resolvedCount}</p>
      </div>
      <div>
        <h4>Starred</h4>
        <p>{starredCount}</p>
      </div>
    </div>
  );
};

export default SummaryHeader;
