import { FILTERS, PRIORITY } from "../data/ticketMeta";
import { useDispatch, useSelector } from "react-redux";
import {
  selectedTicketNow,
  updateTicketStatus,
  updatePriority,
  toggleStar,
} from "../store/ticketSlice";

const TicketDetails = () => {
  const dispatch = useDispatch();
  const selectedTicket = useSelector((state) =>
    selectedTicketNow(state.ticket),
  );
  return selectedTicket ? (
    <div className="max-w-5xl mx-auto bg-white border rounded-xl p-6 shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-400 text-sm">{selectedTicket.id}</p>

          <h1 className="text-3xl font-bold text-gray-800 mt-2">
            {selectedTicket.issueTitle}
          </h1>
        </div>

        <span
          className={`px-4 py-1 rounded-full text-sm font-medium
          ${
            selectedTicket.status === "Open"
              ? "bg-orange-100 text-orange-600"
              : selectedTicket.status === "In Progress"
                ? "bg-yellow-100 text-yellow-700"
                : "bg-green-100 text-green-600"
          }`}
        >
          {selectedTicket.status}
        </span>
      </div>

      <hr className="my-6" />

      <div className="grid grid-cols-2 gap-y-8">
        <div>
          <p className="text-sm uppercase tracking-wider text-gray-400">
            Customer
          </p>

          <p className="font-semibold text-lg mt-1">
            {selectedTicket.customerName}
          </p>
        </div>

        <div>
          <p className="text-sm uppercase tracking-wider text-gray-400">
            Assigned To
          </p>

          <p className="font-semibold text-lg mt-1">
            {selectedTicket.assignedTo}
          </p>
        </div>

        <div>
          <p className="text-sm uppercase tracking-wider text-gray-400">
            Priority
          </p>

          <span
            className={`inline-block mt-1 px-2 py-1 text-xs rounded font-semibold
            ${
              selectedTicket.priority === "High"
                ? "bg-red-100 text-red-600"
                : selectedTicket.priority === "Medium"
                  ? "bg-orange-100 text-orange-600"
                  : "bg-green-100 text-green-600"
            }`}
          >
            {selectedTicket.priority.toUpperCase()}
          </span>
        </div>

        <div>
          <p className="text-sm uppercase tracking-wider text-gray-400">
            Starred
          </p>

          <p className="font-semibold mt-1">
            {selectedTicket.starred ? "⭐ Yes" : "☆ No"}
          </p>
        </div>
      </div>

      <hr className="my-6" />

      <div>
        <p className="text-sm uppercase tracking-wider text-gray-400 mb-2">
          Description
        </p>

        <p className="text-gray-700">{selectedTicket.description}</p>
      </div>

      <div className="mt-8 space-y-5">
        <div>
          <label className="block text-sm uppercase tracking-wider text-gray-400 mb-2">
            Status
          </label>

          <select
            value={selectedTicket.status}
            onChange={(e) => {
              console.log(e.target.value);
              dispatch(
                updateTicketStatus({
                  id: selectedTicket.id,
                  status: e.target.value,
                }),
              );
            }}
            className="w-full border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {FILTERS.map((f) => {
              if (f !== "All")
                return (
                  <option key={f} value={f}>
                    {f}
                  </option>
                );
            })}
          </select>
        </div>

        <div>
          <label className="block text-sm uppercase tracking-wider text-gray-400 mb-2">
            Priority
          </label>

          <select
            value={selectedTicket.priority}
            onChange={(e) =>
              dispatch(
                updatePriority({
                  id: selectedTicket.id,
                  priority: e.target.value,
                }),
              )
            }
            className="w-full border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {PRIORITY.map((p) => (
              <option key={p} value={p}>
                {p.toUpperCase()}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={() => dispatch(toggleStar(selectedTicket.id))}
          className="w-full border rounded-lg py-3 hover:bg-gray-50 transition font-medium"
        >
          {selectedTicket.starred ? "★ Remove Star" : "☆ Star this ticket"}
        </button>
      </div>
    </div>
  ) : (
    <div className="h-full flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-semibold text-gray-500">
          No Ticket Selected
        </h2>
        <p className="text-gray-400 mt-2">
          Select a ticket from the list to view details.
        </p>
      </div>
    </div>
  );
};

export default TicketDetails;
